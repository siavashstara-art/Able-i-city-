import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.icity.core',
  appName: 'ICity Core',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
